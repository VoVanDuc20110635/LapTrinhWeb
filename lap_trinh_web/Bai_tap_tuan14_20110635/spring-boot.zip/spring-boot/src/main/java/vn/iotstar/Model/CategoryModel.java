package vn.iotstar.Model;

import javax.validation.constraints.NotEmpty;

import org.hibernate.validator.constraints.Length;

import org.springframework.web.multipart.MultipartFile;

import lombok.*;

@Data

@AllArgsConstructor

@NoArgsConstructor

public class CategoryModel {

	private Long categoryId;

	private String categorycode;

	@NotEmpty
	@Length(min = 5)
	private String categoryname;

	private MultipartFile imageFile; // lưu hình

	private String images;

	private boolean status;

	private Boolean isEdit = false;

}