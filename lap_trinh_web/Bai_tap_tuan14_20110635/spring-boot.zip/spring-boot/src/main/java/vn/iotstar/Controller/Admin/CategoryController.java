package vn.iotstar.Controller.Admin;

import java.util.List;

import java.util.Optional;

import java.util.stream.Collectors;

import java.util.stream.IntStream;

import javax.validation.Valid;

import org.springframework.beans.BeanUtils;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.domain.Page;

import org.springframework.data.domain.PageRequest;

import org.springframework.data.domain.Pageable;

import org.springframework.data.domain.Sort;

import org.springframework.stereotype.Controller;

import org.springframework.ui.ModelMap;

import org.springframework.util.StringUtils;

import org.springframework.validation.BindingResult;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.servlet.ModelAndView;

import vn.iotstar.Entity.Category;
import vn.iotstar.Service.ICategoryService;



@Controller

@RequestMapping("admin/categories")

public class CategoryController {

	@Autowired

	ICategoryService categoryService;

	@RequestMapping("")
	public String list(ModelMap model) {

		//gọi hàm findAll() trong service

		List<Category> list = categoryService.findAll();

		//chuyển dữ liệu từ list lên biến categories 

		model.addAttribute("categories", list);

		return "admin/categories/listcategory";

	}
	
}
